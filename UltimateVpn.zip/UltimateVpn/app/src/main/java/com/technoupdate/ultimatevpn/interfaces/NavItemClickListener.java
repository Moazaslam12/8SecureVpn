package com.technoupdate.ultimatevpn.interfaces;

public interface NavItemClickListener {
    void clickedItem(int index);
    void onLongclickedItem(int index);
}
