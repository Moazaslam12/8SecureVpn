package com.technoupdate.ultimatevpn;

import android.app.Application;

import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.technoupdate.ultimatevpn.utils.DataUtil;
import com.technoupdate.ultimatevpn.utils.SharedPreference;
import com.technoupdate.ultimatevpn.worker.ServerUpdate;

import java.util.concurrent.TimeUnit;

public class GlobalApp extends Application {

    private static GlobalApp instance;
    private static boolean isImportToOpenVPN = false;
    private DataUtil dataUtil;

    public static String getResourceString(int resId) {
        return instance.getString(resId);
    }

    public static GlobalApp getInstance() {
        return instance;
    }

    public static boolean isIsImportToOpenVPN() {
        return isImportToOpenVPN;
    }

    public DataUtil getDataUtil() {
        return dataUtil;
    }

    @Override
    public void onCreate() {
        SharedPreference.INSTANCE.init(this);
        instance = this;
        dataUtil = new DataUtil(this);
        PeriodicWorkRequest mPeriodicWorkRequest = new PeriodicWorkRequest.Builder(ServerUpdate.class,
                2, TimeUnit.HOURS)
                .addTag("periodicWorkRequest")
                .build();
        WorkManager.getInstance().enqueue(mPeriodicWorkRequest);
        super.onCreate();
    }
}
