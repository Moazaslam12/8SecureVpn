package com.technoupdate.ultimatevpn.interfaces;

import com.technoupdate.ultimatevpn.model.Server;

public interface ChangeServer {
    void newServer(Server server);
}
