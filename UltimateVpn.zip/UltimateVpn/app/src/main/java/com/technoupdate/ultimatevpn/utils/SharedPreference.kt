package com.technoupdate.ultimatevpn.utils

import android.content.Context
import android.content.SharedPreferences
import com.technoupdate.ultimatevpn.R
import com.technoupdate.ultimatevpn.utils.Utils.getImgURL
import com.technoupdate.ultimatevpn.model.Server

object SharedPreference {

    private const val APP_PREFS_NAME = "UltimateVPNPreference"
    private const val SERVER_COUNTRY = "server_country"
    private const val SERVER_FLAG = "server_flag"
    private const val SERVER_OVPN = "server_ovpn"
    private const val SERVER_OVPN_USER = "server_ovpn_user"
    private const val SERVER_OVPN_PASSWORD = "server_ovpn_password"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(
            APP_PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Save server details
     * @param server details of ovpn server
     */
    fun saveServer(server: Server) {
        val prefsEditor: SharedPreferences.Editor = prefs.edit()
        with(prefsEditor) {
            putString(SERVER_COUNTRY, server.country)
            putString(SERVER_FLAG, server.flagUrl)
            putString(SERVER_OVPN, server.ovpn)
            putString(SERVER_OVPN_USER, server.ovpnUserName)
            putString(SERVER_OVPN_PASSWORD, server.ovpnUserPassword)
            commit()
        }
    }

    /**
     * Get server data from shared preference
     * @return server model object
     */
    fun getServer(): Server {
        with(prefs){
            return Server(getString(SERVER_COUNTRY, "Japan"),
                getString(
                    SERVER_FLAG, getImgURL(
                        R.drawable.japan
                    )),
                getString(SERVER_OVPN, "japan.ovpn"),
                getString(SERVER_OVPN_USER, "vpn"),
                getString(SERVER_OVPN_PASSWORD, "vpn"))
        }
    }

}